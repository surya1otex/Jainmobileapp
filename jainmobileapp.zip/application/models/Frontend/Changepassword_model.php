<?php if(!defined('BASEPATH')) exit('No direct script access allowed');


class Changepassword_model extends CI_Model
{

    function matchOldPassword($userId, $oldPassword)
    {
        $this->db->select('userId, password');
        $this->db->where('userId', $userId);        
        $this->db->where('isDeleted', 0);
        $query = $this->db->get('tbl_users');
        
        $user = $query->result();

        if(!empty($user)){
            if(verifyHashedPassword($oldPassword, $user[0]->password)){
                return $user;
            } else {
                return array();
            }
        } else {
            return array();
        }
    }
    function samepasswordcheck($oldpassword,$newpassword) {

         if($oldpassword == $newpassword) {
             $status = TRUE;
         }
         else {
            $status = FALSE;
        }

        return $status;

    }

    function changePassword($userId, $userInfo)
    {
        $this->db->where('userId', $userId);
        $this->db->where('isDeleted', 0);
        $this->db->update('tbl_users', $userInfo);
        
        return $this->db->affected_rows();
    }
}